<?php

namespace App\Http\Controllers;
use App\users;
use Illuminate\Http\Request;
use \Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;



class senders extends Controller
{
  public function insert()
      {
         $urlData = getURLList();
         return view('home');
      }


         //  submitmyform Function Starts
       public function create(Request $request)
        {
          // validation starts
           $this->validate($request,[
              "name"=>"required",
              "email"=>"required|email|min:8|",
              "message"=>"required"
              ],[
                  "name.required"=>"Name Should be filled",
                  "email.min"=>" Email length should be more than 8",
                  "email.email"=>"Enter a Valid E-mail"
              ]);
                   // validation ends

                  //Database insertion code starts
              $name = $request->input('name');
              $email = $request->input('email');
              $message = $request->input('message');
              $data=array('name'=>$name,"email"=>$email,"message"=>$message);
              DB::table('senders')->insert($data);
                 //Database insertion code ends

           die("Form Submitted");
        }
}
