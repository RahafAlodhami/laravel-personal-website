
  		<?php
	

      $name = $_REQUEST['name'];
    	$email  = $_REQUEST['email'];
    	$message = $_REQUEST['message'];


  		$sql = "INSERT INTO senders VALUES ('$name',
  			'$email','$message')";

  		if(mysqli_query($conn, $sql)){
  			echo "<h6>data stored in a database successfully </h6>";}
?>
