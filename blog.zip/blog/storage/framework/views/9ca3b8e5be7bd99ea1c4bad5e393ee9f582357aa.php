<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rahaf Alodhami</title>
    <link rel="shortcut icon" href="/img/LOGO.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="/css/main.css" rel="stylesheet">
    <script src="Java.js"></script>
    <script src= "https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

       <script>
           $(document).ready(function () {
               var max_length = 900;
               $('textarea').keyup(function () {
                   var len = max_length - $(this).val().length;
                   $('.GFG').text(len);
               });

           });
       </script>
</head>
<body>


    <nav class="navbar">
        <ul>
            <div><img src="/img/LOGO.png" alt="logo"> </div>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#portfolio">Portfolio</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </nav>


    <section id="home">
      <div class="gif1">
        <img src="/img/holo.gif" alt=" home GIF"> </div>
        <h1 class="heading">HI, I AM</h1>
        <h1 class="heading"> RAHAF ALODHAMI</h1>
        <br><br>
        <p>AND THIS IS MY PERSONAL WEBSITE</p>

    </section>


        <section id="about">
            <h1 class="heading">About Me</h1>
            <div class="about">
                <img src="/img/about.gif" alt="about GIF">
                <div class="name">
                  <h2>I'm Rahaf Alodhami</h2>
                    <p>
                    A self-driven, multitasking, flexible, detail-oriented, quick starter, with a good communication skills and a curious mind. Born in Al Ain on 1998 November 19th and raised in Saudi Arabia. I am an Information Management Grad Student at Imam Mohammad Ibn Saud Islamic University. Interested in Front End Development, UX Design, Project Management, System Analysis and Photography. My computer skills are Java, Html, Microsoft office, SQL, CSS, R, PHP, JavaScript. My experiences are, I Volunteered in DSCA foundation, Also in Saudi digital family initiative. Took a knowledge management and innovation course, An information security course Also, a data science and analysis course. Attended a workshop for Artificial Intelligence cloud computing all industries in Saudi universities. Arabic is my mother language and I am fluent in English.</p>
                </div>
            </div>
        </section>


    <section id="portfolio">
       <h1 class="heading">Portfolio</h1>
       <section class="slideshow">
         <div class="slideshow-container slide">

     <div class="item">
         <img src="/img/lake.jpeg" />
         <div class="caption">A lake in Saudi Arabia</div>
      </div>

     <div class="item">
         <img src="/img/tree.jfif" />
         <div class="caption">Sunset</div>
      </div>

      <div class="item">
          <img src="/img/zbeauty1.jpg" />
          <div class="caption">My first website</div>
      </div>

    </div>
  </section>
  </section>


    <section id="contact">
        <h1 class="heading">Contact Me</h1>
        <div id="error_message">
        </div>
        <form action="/create" method="post" id="myform" onsubmit = "return validate();" class="form">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?> ">
            <input id="name" type="text" name="name" class="input" placeholder="Enter Your Name" required>
            <input id="email" type="email" name="email" class="input" placeholder="Enter Your Email"required>
            <p> <span class="GFG">900</span> Characters Remaining </p>
            <textarea name="message" id="message" cols="70" rows="15" placeholder="Enter Your Message" maxlength="900"required></textarea>

            <input type="submit" value="Submit" id="submit">
        </form>

    </section>


    <footer class="text-center">
            <div class="footer">
        <a class="icon" href="https://www.linkedin.com/in/rahaf-alodhami-a92bb4161" target="_blank">
        <i class="fab fa-linkedin"> </i>
       </a>
            </div>
                <p>© 2021 RAHAF ALODHAMI - All Rights Reserved</p>

    </footer>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\Assignment2-RahafAlodhami - responsive - Copy\blog\resources\views/home.blade.php ENDPATH**/ ?>